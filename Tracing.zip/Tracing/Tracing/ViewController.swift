//
//  ViewController.swift
//  Tracing
//
//

import UIKit
import CoreLocation

class ViewController: UIViewController, LocationServiceDelegate {
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var latLabel: UILabel!
    @IBOutlet weak var lonLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        LocationService.sharedInstance.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: Action
    @IBAction func startButtonTapped(_ sender: AnyObject) {
        LocationService.sharedInstance.startUpdatingLocation()
    }
    
    @IBAction func stopButtonTapped(_ sender: AnyObject) {
        LocationService.sharedInstance.stopUpdatingLocation()
    }
    
    // MARK: LocationService Delegate
    func tracingLocation(_ currentLocation: CLLocation) {
        let lat = currentLocation.coordinate.latitude
        let lon = currentLocation.coordinate.longitude
        
        latLabel.text = "lat : \(lat)"
        lonLabel.text = "lon : \(lon)"
    }
    
    func tracingLocationDidFailWithError(_ error: NSError) {
        print("tracing Location Error : \(error.description)")
    }

}

